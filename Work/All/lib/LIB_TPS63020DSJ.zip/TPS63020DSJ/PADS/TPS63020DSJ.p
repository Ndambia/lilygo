*PADS-LIBRARY-PART-TYPES-V9*

TPS63020DSJ TPS63020DSJR I ANA 9 1 0 0 0
TIMESTAMP 2026.08.24.21.41.39
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS63020DSJ
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Buck-Boost Switching Regulator IC Positive Adjustable 1.2V 1 Output 3.5A (Switch) 14-VFDFN Exposed Pad
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tps63020.pdf?HQS=dis-dk-null-digikeymode-dsf-pf-null-wwe&ts=1623612296427
"Geometry.Height" 1mm
GATE 1 23 0
TPS63020DSJ
1 0 U VINA
2 0 U GND
3 0 U FB
4 0 U VOUT_1
5 0 U VOUT_2
6 0 U L2_1
7 0 U L2_2
8 0 U L1_1
9 0 U L1_2
10 0 U VIN_1
11 0 U VIN_2
12 0 U EN
13 0 U PS/SYNC
14 0 U PG
15 0 U PGND_1
16 0 U PGND_2
17 0 U PGND_3
18 0 U PGND_4
19 0 U PGND_5
20 0 U PGND_6
21 0 U PGND_7
22 0 U PGND_8
23 0 U PGND_9

*END*
*REMARK* SamacSys ECAD Model
20862191/810120/2.50/23/4/Integrated Circuit
